package com.bksx.nettest.bean;

public class FanxingB extends FanxingA {

    int a;

    public int getA() {
        return a;
    }

    public void setA(int a) {
        this.a = a;
    }
}
