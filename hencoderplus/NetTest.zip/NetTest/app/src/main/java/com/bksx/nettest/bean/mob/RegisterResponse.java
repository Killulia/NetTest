package com.bksx.nettest.bean.mob;

public class RegisterResponse {

    /**
     * retCode : 200
     * msg : success
     * uid : e5b0d1b60461ea4605cf27947f739bce
     */

    private String retCode;
    private String msg;
    private String uid;

    public String getRetCode() {
        return retCode;
    }

    public void setRetCode(String retCode) {
        this.retCode = retCode;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }
}
