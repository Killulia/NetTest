package com.bksx.nettest.bean.test;

public class AResponse extends BaseResponse<AVbsBean> {
}
