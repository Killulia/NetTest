package com.bksx.nettest.bean.test;

public class BResponse extends BaseResponse <BVcsBean>{
}
