package com.bksx.nettest.bean.test;

public class BVcsBean {
}
