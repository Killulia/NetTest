package com.bksx.nettest.bean.test;

import java.util.List;

public class ReturnData<T> {

    private List<T> datas;

    public List<T> getDatas() {
        return datas;
    }
}
