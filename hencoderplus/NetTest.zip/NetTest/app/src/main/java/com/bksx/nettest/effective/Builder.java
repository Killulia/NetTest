package com.bksx.nettest.effective;

public interface Builder <T>{
    public T build();
}
