package com.bksx.nettest.effective;

import com.bksx.nettest.testpackage.HashMapUtil;

import java.util.HashMap;

public class C2_1 {

    public C2_1() {}

    HashMap<String,String> hashMap = HashMapUtil.newInstance();
}
