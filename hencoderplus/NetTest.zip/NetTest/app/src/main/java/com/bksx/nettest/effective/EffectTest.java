package com.bksx.nettest.effective;

public class EffectTest {
    public void test(){
        C2_2 c2_2 = new C2_2.Builder(1,"tmac")
                .bir("1979")
                .conutry("USA")
                .gentle("male")
                .no(131203234)
                .build();


    }
}
