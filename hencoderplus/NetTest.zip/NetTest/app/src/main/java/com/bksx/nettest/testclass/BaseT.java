package com.bksx.nettest.testclass;

public  class BaseT {

    public BaseT() {
        print();
    }

    public  void print(){}
}
