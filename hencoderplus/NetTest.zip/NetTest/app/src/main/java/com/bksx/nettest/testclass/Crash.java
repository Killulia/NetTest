package com.bksx.nettest.testclass;

import android.util.Log;

public abstract class Crash {
    int value;
    public void test(){
        Log.d("Crash", "nothing");
    }
}
