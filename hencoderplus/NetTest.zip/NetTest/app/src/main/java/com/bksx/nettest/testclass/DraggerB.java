package com.bksx.nettest.testclass;

import javax.inject.Inject;

public class DraggerB {
    @Inject

    public DraggerB() {
    }
}
