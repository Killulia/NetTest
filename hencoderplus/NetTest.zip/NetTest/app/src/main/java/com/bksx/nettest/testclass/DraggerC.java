package com.bksx.nettest.testclass;

import javax.inject.Inject;

public class DraggerC {
    @Inject

    public DraggerC() {
    }
}
