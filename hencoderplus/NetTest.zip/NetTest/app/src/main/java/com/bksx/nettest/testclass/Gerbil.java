package com.bksx.nettest.testclass;

import android.util.Log;

public class Gerbil extends Rodent {
    @Override
    public void play() {
        Log.d("Rodent", "鼹鼠");
    }
}
