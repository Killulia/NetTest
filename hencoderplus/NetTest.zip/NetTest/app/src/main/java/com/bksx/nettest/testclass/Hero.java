package com.bksx.nettest.testclass;
@Test
public class Hero {

    @Deprecated
    public void say(){
        System.out.println("Noting has to say!");
    }

    public void speak(){
        System.out.println("I have a dream!");
    }
}
