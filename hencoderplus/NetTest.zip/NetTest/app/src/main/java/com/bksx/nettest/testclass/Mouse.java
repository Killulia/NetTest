package com.bksx.nettest.testclass;

import android.util.Log;

public class Mouse extends Rodent {


    @Override
    public void play() {
        Log.d("Rodent", "老鼠");

    }
}

