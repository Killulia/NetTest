package com.bksx.nettest.testclass;

import android.util.Log;

public abstract class Rodent {

    public abstract void play();

}
