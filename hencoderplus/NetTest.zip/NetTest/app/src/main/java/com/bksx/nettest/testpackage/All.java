package com.bksx.nettest.testpackage;

public interface All extends First,Second,Third{
    void doAll();
}
