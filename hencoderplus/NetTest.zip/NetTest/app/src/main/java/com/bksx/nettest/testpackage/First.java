package com.bksx.nettest.testpackage;

public interface First {
    void doFirst();
    void atFirst();
}
