package com.bksx.nettest.testpackage;

import java.util.HashMap;

public class HashMapUtil {
    public static <K,V>HashMap<K,V> newInstance(){
        return new HashMap<K, V>();
    }
}
