package com.bksx.nettest.testpackage;

abstract class MyAbs {
    abstract void doAbs();
}
