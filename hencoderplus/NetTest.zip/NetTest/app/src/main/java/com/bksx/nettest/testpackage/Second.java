package com.bksx.nettest.testpackage;

public interface Second {
    void doSecond();
    void atSecond();
}
