package com.bksx.nettest.testpackage;

public interface TestInterface {
    void test1();
    void test2();
    void test3();
}
