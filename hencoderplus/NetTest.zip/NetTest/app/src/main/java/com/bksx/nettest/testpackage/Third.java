package com.bksx.nettest.testpackage;

public interface Third {
    void doThird();
    void atThird();
}
