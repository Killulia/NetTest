package com.bksx.nettest.utils;

/**
 * Created by try on 2018/5/8.
 */

public class Constants {

    public static final String BASE_URL = "http://v.juhe.cn/";
    public static final String ID_BASE_URL = "http://apis.juhe.cn/";

    public static final String TEST_URL = "http://v.juhe.cn/toutiao/index?";
//    type=top&key=6ce2dfc57ad2abef3f6a51cf02cf9993

    public static final String ID_URL = "http://apis.juhe.cn/idcard/";
//    http://apis.juhe.cn/idcard/index?key=C5691E6FCDF9263B63C9A9117CC4D163&cardno=211122199406193311
//    http://apis.juhe.cn/idcard/index?key=c5691e6fcdf9263b63c9a9117cc4d163&cardno=211122199406193311

    public static final String IMG_URL = "https://timgsa.baidu.com/";

    public static final String MOB_BASE = "http://apicloud.mob.com/";

    public static final String APP_KEY = "c5691e6fcdf9263b63c9a9117cc4d163";


}
