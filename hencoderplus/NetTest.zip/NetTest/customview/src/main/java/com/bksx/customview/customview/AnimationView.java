package com.bksx.customview.customview;

import android.content.Context;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;

public class AnimationView extends View {

    public AnimationView(Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
    }
}
