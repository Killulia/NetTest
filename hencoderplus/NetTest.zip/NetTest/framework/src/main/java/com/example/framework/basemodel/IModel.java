package com.example.framework.basemodel;

public interface IModel {
}
