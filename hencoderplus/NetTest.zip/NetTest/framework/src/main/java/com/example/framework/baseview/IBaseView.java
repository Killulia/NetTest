package com.example.framework.baseview;

import com.example.framework.basemodel.BaseModel;
import com.example.framework.bean.ToutiaoBean;

public interface IBaseView<M extends ToutiaoBean> extends IView {

}
