package com.example.framework.baseview;

public interface IView {
}
