package com.bksx.mvptest.util;

public class Constans {

    public static final String IMG_URL = "https://timgsa.baidu.com/";

}
