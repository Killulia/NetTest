package com.bksx.mvptest.view.interfaces;

import android.graphics.Bitmap;

public interface MainView {

    public void showImg(Bitmap bitmap);

}
